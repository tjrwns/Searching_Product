/*/
http://localhost:49781/ui/Page/Map/Leaflet/index.html
http://dnsproxy.shop:49781/ui/Page/Map/Leaflet/index.html
//*/
//----------------------------------------------------------------------------------------------------;

//	IMPORT;

//----------------------------------------------------------------------------------------------------;

(function(){
	var HOST = window.b2link.url.getServerURL_WebServer_SCODE( "SYS0015" );

	var f = window.b2link.util.importJS__Reuse;

		f( HOST + "/js--GIS/___merge_min_all_1_0.js" );

	//CSS;
	var f = SUtilTemplateHTML.addCSS__URLToHead;
		f( HOST + "/libs/Leaflet/leaflet.css" );
	//JS;
	//var f = window.b2link.util.importJS__Reuse;
	var f = SUtilTemplateHTML.addJS__URLToHead;
		f( HOST + "/libs/Leaflet/leaflet.js", initialize );
})();

//----------------------------------------------------------------------------------------------------;

//	PACKAGE;

//----------------------------------------------------------------------------------------------------;

window.GIS = window.GIS || {};

//----------------------------------------------------------------------------------------------------;

//	DEFINE;

//----------------------------------------------------------------------------------------------------;

/**
 * @const
 * @property
 */
var _CLASS = (function(){
	return {
		MAP : "ui-Page-Map-Leaflet-index--map"
	};
})();

/**
 * @const
 * @property
 */
var _IDS = (function(){
	return {
		MAP_CONTAINER : "ui/Page/Map/Leaflet/index"
	};
})();

/**
 * @const
 * @property
 */
var _ELS = (function(){
	var o = {
		MAP_CONTAINER : window.document.getElementById( _IDS.MAP_CONTAINER )
	};

	o.MAP = window.b2link.element.getElementByClassName( o.MAP_CONTAINER, _CLASS.MAP );
	o.MAP.id = SUtilMath.getUnique();

	return o;
})();

/**
 * @const
 * @property
 */
var _URLS = {};

//----------------------------------------------------------------------------------------------------;

//	EVENT;

//----------------------------------------------------------------------------------------------------;

/**
 * @function
 */
function initialize()
{
	try
	{
		SUtilGISLeaflet = STtwUtilGISLeaflet;

		var MAP = window.ttw.gis.create_Map({ id : _ELS.MAP.id, continuousWorld : true, worldCopyJump : false, zoomControl : true, inertia : false
			, center : { lat : 38, lng : 127 }, zoom : 8
		});

		var MAP_CONTROLS = {};
			MAP_CONTROLS.attribution = window.ttw.gis.addControl_Attribution({ map : MAP, position : "bottomright", prefix : "B2Labs" });
			MAP_CONTROLS.scaleLine = window.ttw.gis.addControl_ScaleLine({ map : MAP, position : "bottomleft", maxWidth : 100, metric : true, imperial : true, updateWhenIdle : false });
			MAP_CONTROLS.zoom = window.ttw.gis.addControl_Zoom({ map : MAP, position : "topleft", zoomInText : "+", zoomOutText : "-", zoomInTitle : "Zoom in", zoomOutTitle : "Zoom out" });

		//*/
		window.ttw.gis.initialize_GeometryEditor({ k : "FeatureGroup_Editor", map : MAP
			, control : {
				position : "topright"
				//position : "topleft"
				, draw : { polyline : true, polygon : true, circle : true, marker : true }
				, edit : { remove : true }
				, event : { draw_created : null, draw_edited : null }
			}
		});
		//*/

		//var MAP_LAYER__CartoDB_DarkMatter = window.ttw.gisPack.tileLayer( "http://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png"
		var MAP_LAYER__CartoDB_DarkMatter = window.ttw.gisPack.tileLayer( "http://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png"
			, { subdomains : "abcd", maxZoom : 19
				//, attribution : '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="http://cartodb.com/attributions">CartoDB</a>'
			}
		);
		window.ttw.gis.addLayer_Dictionary( MAP, MAP_LAYER__CartoDB_DarkMatter, MAP.DIC_LAYERS, "BASE_MAP" );

		var maps = {
			map : MAP, map_el : _ELS.MAP, controls : MAP_CONTROLS, layers : MAP.DIC_LAYERS
			, redrawAllLayers : function(){ for( var s in MAP.DIC_LAYERS ){ MAP.DIC_LAYERS[ s ].redraw(); } }
		};

		//STATIC REFERENCE;
		window.GIS.MAP_BASIC = maps;

		//지도 기본 위치;
		MAP.setView( [ 37.510372649468756, 126.92659378051759 ], 12 );

		initialize._bInit = 1;
	}
	catch( e )
	{
		window.console.log( "[ ERROR ] - " + e );
		return;
	}
};
initialize._bInit = 0;

//----------------------------------------------------------------------------------------------------;

//	FUNCTION;

//----------------------------------------------------------------------------------------------------;

//----------------------------------------------------------------------------------------------------;

//	LOGIC;

//----------------------------------------------------------------------------------------------------;

if( !initialize._bInit ) initialize();

//----------------------------------------------------------------------------------------------------;
