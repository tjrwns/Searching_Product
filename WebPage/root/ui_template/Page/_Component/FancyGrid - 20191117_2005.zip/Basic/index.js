/*/
http://localhost:49781/ui/Page/FancyGrid/Basic/index.html?width=500&height=500

//사이즈를 %로 적용;
http://localhost:49781/ui/Page/FancyGrid/Basic/index.html?width=100%25%26height=500
http://localhost:49781/ui/Page/FancyGrid/Basic/index.html?width=100%25%26height=800

//사이즈를 %로 적용 - Height는 적용 안됨;
http://localhost:49781/ui/Page/FancyGrid/Basic/index.html?width=100%25%26height=100%25%26

http://localhost:49781/ui/Page/FancyGrid/Basic/index.html?url=http://localhost:49781/ui/Page/Chart/EChart/Bar/index.tjson
http://dnsproxy.shop:49781/ui/Page/Chart/EChart/Bar/index.html?url=http://dnsproxy.shop:49780/country/brand
//*/
//----------------------------------------------------------------------------------------------------;
var fileNm = "ui/Page/FancyGrid/Basic/index.js";
if( console ) console.log( "[ S ] - " + fileNm + "----------" );
//----------------------------------------------------------------------------------------------------;

var _THIS = {};

//----------------------------------------------------------------------------------------------------;

//	IMPORT;

//----------------------------------------------------------------------------------------------------;

(function(){
	var HOST = window.b2link.url.getServerURL_WebServer_SCODE( "SYS0015" );

	var f = window.b2link.util.importJS__Reuse;
		f( HOST + "/libs/FancyGrid/import-js.js" );

	//CSS;
	var f = SUtilTemplateHTML.addCSS__URLToHead;
		//f( HOST + "/libs/Leaflet/leaflet.css" );
	//JS;
	//var f = window.b2link.util.importJS__Reuse;
	var f = SUtilTemplateHTML.addJS__URLToHead;
		//f( HOST + "/libs/Leaflet/leaflet.js", initialize );
})();

//----------------------------------------------------------------------------------------------------;

//	PACKAGE;

//----------------------------------------------------------------------------------------------------;

//----------------------------------------------------------------------------------------------------;

//	DEFINE;

//----------------------------------------------------------------------------------------------------;

/**
 * @const
 * @property
 */
var _CLASS = (function(){
	return {
	};
})();

/**
 * @const
 * @property
 */
var _IDS = (function(){
	return {
		ROOT : "ui/Page/FancyGrid/Basic/index"
	};
})();

/**
 * @const
 * @property
 */
var _ELS = (function(){
	var o = {
		ROOT : window.document.getElementById( _IDS.ROOT )
	};

	for( var s in o ) if( o[ s ].id ) o[ s ].id += "--" + SUtilMath.getUnique();

	return o;
})();

/**
 * @const
 * @property
 */
var _FANCYGRID = (function(){
	return {
		GRID : null
	};
})();


var _THIS = {};

/**
 * @const
 * @property
 */
var _URLS = {};

//접속 URL에서 URI PARAMETERS를 추출;
var _DATA = (function(){
	var d = SUtilLocation.getObjectFromParamters();
	var r;
	if( d.url )
	{
		//var url = window.b2link.uri.getURIReplaceSharp__JSON( d.url );
		var url = window.b2link.uri.encodeURIComponent( d.url );

		r = window.b2link.xhr.reqSync_JSON( url );
	}
	else
	{
		r = {
			title : "FancyGrid Basic"
			, columns : [
				{ index : "company", title : "Company", type : "string" }//, width : 100;
				, { index : "name", title : "Name", type : "string" }//, width : 100;
				, { index : "surname", title : "Sur Name", type : "string" }//, width : 100;
				, { index : "age", title : "Age", type : "number" }//, width : 100;
			]
			, data : [
				{"name":"Ted","surname":"Smith","company":"Electrical Systems","age":30}
				,{"name":"Ed","surname":"Johnson","company":"Energy and Oil","age":35}
				,{"name":"Sam","surname":"Williams","company":"Airbus","age":38}
				,{"name":"Alexander","surname":"Brown","company":"Renault","age":24}
				,{"name":"Nicholas","surname":"Miller","company":"Adobe","age":33}
				,{"name":"Andrew","surname":"Thompson","company":"Google","age":28}
				,{"name":"Ryan","surname":"Walker","company":"Siemens","age":39}
				,{"name":"John","surname":"Scott","company":"Cargo","age":45}
				,{"name":"James","surname":"Phillips","company":"Pro bugs","age":30}
				,{"name":"Brian","surname":"Edwards","company":"IT Consultant","age":23}
				,{"name":"Jack","surname":"Richardson","company":"Europe IT","age":24}
				,{"name":"Alex","surname":"Howard","company":"Cisco","age":27}
				,{"name":"Carlos","surname":"Wood","company":"HP","age":36}
				,{"name":"Adrian","surname":"Russell","company":"Micro Systems","age":31}
				,{"name":"Jeremy","surname":"Hamilton","company":"Big Machines","age":30}
				,{"name":"Ed","surname":"Johnson","company":"Energy and Oil","age":35}
				,{"name":"Sam","surname":"Williams","company":"Airbus","age":38}
				,{"name":"Alexander","surname":"Brown","company":"Renault","age":24}
				,{"name":"Nicholas","surname":"Miller","company":"Adobe","age":33}
				,{"name":"Andrew","surname":"Thompson","company":"Google","age":28}
				,{"name":"Ryan","surname":"Walker","company":"Siemens","age":39}
				,{"name":"John","surname":"Scott","company":"Cargo","age":45}
				,{"name":"James","surname":"Phillips","company":"Pro bugs","age":30}
				,{"name":"Brian","surname":"Edwards","company":"IT Consultant","age":23}
				,{"name":"Jack","surname":"Richardson","company":"Europe IT","age":24}
				,{"name":"Alex","surname":"Howard","company":"Cisco","age":27}
				,{"name":"Carlos","surname":"Wood","company":"HP","age":36}
				,{"name":"Adrian","surname":"Russell","company":"Micro Systems","age":31}
				,{"name":"Jeremy","surname":"Hamilton","company":"Big Machines","age":30}
			]
		};
	}

	if( d.width ) r.width = d.width;
	if( d.height ) r.height = d.height;

	return r;
})();

//--------------------------------------------------;

/**
 * @const
 * @property
 */
var _OPTIONS__SAMPLE = {
	renderTo : _ELS.ROOT
	//, width : 550, height : 500
	//, width : "100%", height : "100%"
	//, width : "fit", height : "fit"

	//, theme : { name : "blue", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12, minCellWidth : 150 } }
	//, theme : { name : "bootstrap", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12, minCellWidth : 150 } }
	, theme : { name : "bootstrap", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12 } }
	//, theme : { name : "dark", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12, minCellWidth : 150 } }
	//, theme : { name : "default", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12, minCellWidth : 150 } }
	//, theme : { name : "gray", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12, minCellWidth : 150 } }

	, data : null

	//----------;
	, bbar : [{ disabled : true, text : "Bottom Bar", type : "button" }]
	, tbar : [{ disabled : true, text : "Top Bar", type : "button" }]
	//----------;

	, columns : null
};

/**
 * @const
 * @property
 */
var _OPTIONS = {
	renderTo : _ELS.ROOT
	, title : ""
	//, width : 550, height : 500
	//, width : "100%", height : "100%"
	//, width : "fit", height : "fit"

	//, theme : { name : "blue", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12, minCellWidth : 150 } }
	//, theme : { name : "bootstrap", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12, minCellWidth : 150 } }
	, theme : { name : "bootstrap", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12 } }
	//, theme : { name : "dark", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12, minCellWidth : 150 } }
	//, theme : { name : "default", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12, minCellWidth : 150 } }
	//, theme : { name : "gray", config : { cellHeaderHeight : 30, cellHeight : 32, titleHeight : 42, barHeight : 37, bottomScrollHeight : 12, minCellWidth : 150 } }

	, data : []

	//----------;
	, bbar : [{ disabled : true, text : "Bottom Bar", type : "button" }]
	, tbar : [{ disabled : true, text : "Top Bar", type : "button" }]
	//----------;

	, columns : null

	,
	events: [
		{
			init: function( grid ){
				_draw( grid );
			}
			click : _evt_click_Cell0

		}
	]
};

//--------------------------------------------------;


//----------------------------------------------------------------------------------------------------;

//	EVENT;

//----------------------------------------------------------------------------------------------------;

var _evt_click_Cell0 = function(){

};

/**
 * @function
 * @param {Event}
 */
var _evt_resize = function( event )
{
	window.clearTimeout( _evt_resize._TIMEOUT );
	_evt_resize._TIMEOUT = window.setTimeout( _evt_resize.resize, 1000 );
};
_evt_resize._TIMEOUT = -1;
_evt_resize.resize = function(){ _redraw(); };

/**
 * @function
 */
function initialize()
{
	try
	{
		if( initialize._bInit ) return;

		//._ELS.ROOT 높이설정;
		_setHeight( _DATA.height );

		//._ELS.ROOT 넓이설정;
		_setWidth( _DATA.width );

		//그리드 렌더;
		_init();

		initialize._bInit = 1;
	}
	catch( e )
	{
		window.console.log( "[ ERROR ] - " + e );
		return;
	}
};
initialize._bInit = 0;

//----------------------------------------------------------------------------------------------------;

//	FUNCTION;

//----------------------------------------------------------------------------------------------------;

/**
 * 그리기
 * @function
 */
var _init = function()
{
	if( _FANCYGRID.GRID != null ) _FANCYGRID.GRID.destroy();

	// _OPTIONS 설정;
	_setOptions( _DATA );

	_FANCYGRID.GRID = new FancyGrid( _OPTIONS );

};


/**
 * 그리기
 * @function
 */
var _draw = function( grid )
{

	grid.showLoadMask('Searching');

	grid.setData( _DATA.data );
	grid.update();

	grid.hideLoadMask();

};

/**
 * 다시 그리기
 * @function
 */
var _redraw = function()
{
	// _OPTIONS 설정;
	_setData( _DATA );

	FANCYGRID.GRID.setData( _DATA.data );
	FANCYGRID.GRID.update();

};

//----------------------------------------------------------------------------------------------------;

//	GETTER / SETTER;

//----------------------------------------------------------------------------------------------------;

//--------------------------------------------------GET;

//--------------------------------------------------SET;

/**
 * 차트 세팅
 * @function
 * @param{Object} d
 * <code>
{
			title : "FancyGrid Basic"
			, columns : [
				{ index : "company", title : "Company", type : "string" }//, width : 100;
				, { index : "name", title : "Name", type : "string" }//, width : 100;
				, { index : "surname", title : "Sur Name", type : "string" }//, width : 100;
				, { index : "age", title : "Age", type : "number" }//, width : 100;
			]
			, data : [
				{"name":"Ted","surname":"Smith","company":"Electrical Systems","age":30}
				,{"name":"Ed","surname":"Johnson","company":"Energy and Oil","age":35}
				,{"name":"Sam","surname":"Williams","company":"Airbus","age":38}
				,{"name":"Alexander","surname":"Brown","company":"Renault","age":24}
				,{"name":"Nicholas","surname":"Miller","company":"Adobe","age":33}
				//.....;
			]
		};
 * </code>
 * @return{Object} option
 */
var _setOptions = function( d )
{
	_OPTIONS.title = d.title;
	//_OPTIONS.data = d.data;
	_OPTIONS.columns = d.columns;

};

/**
 * 데이터 세팅
 * @function
 * @param {Object} d
 * <code>
	{
		url : ""
	}
 * </code>
 */
var _setData = function( d )
{
	if( d.url )
	{
		//var url = window.b2link.uri.getURIReplaceSharp__JSON( d.url );
		var url = window.b2link.uri.encodeURIComponent( d.url );

		_DATA = window.b2link.xhr.reqSync_JSON( url );
	}

};

//--------------------------------------------------GET & SET;

var _getHeight = function(){ return _ELS.ROOT.style.height; };
var _setHeight = function( s ){

	//if( null == s ) var s = _ELS.ROOT.parentElement.clientHeight || ( window.screen.availHeight + _setHeight.TERM_HEIGHT );
	if( null == s ) var s = _ELS.ROOT.parentElement.clientHeight || window.innerHeight;
	var n = Number( s );

	if( "number" == typeof( n ) ) _ELS.ROOT.style.height = s + "px";
	else if( -1 != s.indexOf( "%" ) || -1 != s.indexOf( "px" ) ) _ELS.ROOT.style.height = s;
};
//_setHeight.TERM_HEIGHT = 0;//ETC;
//_setHeight.TERM_HEIGHT = -128;//EChart;

var _getWidth = function(){ return _ELS.ROOT.style.width; };
var _setWidth = function( s ){

	//if( null == s ) var s = _ELS.ROOT.parentElement.clientHeight || ( window.screen.availHeight + _setHeight.TERM_HEIGHT );
	if( null == s ) var s = _ELS.ROOT.parentElement.clientWidth || window.innerWidth;

	var n = Number( s );

	if( "number" == typeof( n ) ) _ELS.ROOT.style.width = s + "px";
	else if( -1 != s.indexOf( "%" ) || -1 != s.indexOf( "px" ) ) _ELS.ROOT.style.width = s;
};

//--------------------------------------------------GETTER & SETTER;

//--------------------------------------------------;

//----------------------------------------------------------------------------------------------------;

//	LOGIC;

//----------------------------------------------------------------------------------------------------;

if( !initialize._bInit ) initialize();

//----------------------------------------------------------------------------------------------------;

/**
 * Chart - EChart Bar
 * @example
 * <code>
 	var els = window.SYS0310_UI_API.echart.addBar();
		els[ 1 ].setData({ url : "http://localhost:49781/ui/Page/Chart/EChart/Bar/index.json" });
		els[ 1 ].redraw();
 * </code>
 */
(function(){
	var _ = _THIS;
		_.els = _ELS

		_.init = _init
		_.draw = _draw
		_.redraw = _redraw
		_.setData = _setData

		_.getHeight = _getHeight
		_.setHeight = _setHeight

		_.getWidth = _getWidth
		_.setWidth = _setWidth

	//Resize 대상 객체를 Observer 패턴에 추가한다;
	//아직 기능 개발 되있지 않음;
	//필수 Interface가 존재함 - 미정의;
	//window.????.????.push( _ );

	return _;
})();